Utilize o seu email cadastrado no Catálogo de imagens do INPE, e substitua seu@email.com pela informação correta.
Cada linha abaixo é um link para baixar os arquivos utilizados na apresentação

https://www.dgi.inpe.br/api/download/TIFF/CBERS4A/2026_02/CBERS_4A_MUX_RAW_2026_02_05.13_30_59_ETC2/214_127_0/4_BC_UTM_WGS84/CBERS_4A_MUX_20260205_214_127_L4_BAND5.tif?email=seu@email.com
https://www.dgi.inpe.br/api/download/TIFF/CBERS4A/2026_02/CBERS_4A_MUX_RAW_2026_02_05.13_30_59_ETC2/214_127_0/4_BC_UTM_WGS84/CBERS_4A_MUX_20260205_214_127_L4_BAND5.xml?email=seu@email.com 
https://www.dgi.inpe.br/api/download/TIFF/CBERS4A/2026_02/CBERS_4A_MUX_RAW_2026_02_05.13_30_59_ETC2/214_127_0/4_BC_UTM_WGS84/CBERS_4A_MUX_20260205_214_127_L4_BAND6.tif?email=seu@email.com 
https://www.dgi.inpe.br/api/download/TIFF/CBERS4A/2026_02/CBERS_4A_MUX_RAW_2026_02_05.13_30_59_ETC2/214_127_0/4_BC_UTM_WGS84/CBERS_4A_MUX_20260205_214_127_L4_BAND6.xml?email=seu@email.com 
https://www.dgi.inpe.br/api/download/TIFF/CBERS4A/2026_02/CBERS_4A_MUX_RAW_2026_02_05.13_30_59_ETC2/214_127_0/4_BC_UTM_WGS84/CBERS_4A_MUX_20260205_214_127_L4_BAND7.tif?email=seu@email.com 
https://www.dgi.inpe.br/api/download/TIFF/CBERS4A/2026_02/CBERS_4A_MUX_RAW_2026_02_05.13_30_59_ETC2/214_127_0/4_BC_UTM_WGS84/CBERS_4A_MUX_20260205_214_127_L4_BAND7.xml?email=seu@email.com 
https://www.dgi.inpe.br/api/download/TIFF/CBERS4A/2026_02/CBERS_4A_MUX_RAW_2026_02_05.13_30_59_ETC2/214_127_0/4_BC_UTM_WGS84/CBERS_4A_MUX_20260205_214_127_L4_BAND8.tif?email=seu@email.com 
https://www.dgi.inpe.br/api/download/TIFF/CBERS4A/2026_02/CBERS_4A_MUX_RAW_2026_02_05.13_30_59_ETC2/214_127_0/4_BC_UTM_WGS84/CBERS_4A_MUX_20260205_214_127_L4_BAND8.xml?email=seu@email.com 
