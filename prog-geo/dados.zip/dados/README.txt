Os dados desse diretório devem ser usados apenas no contexto das aulas pois podem conter modificações e ajustes para o propósito de ensino.

Caso deseje consultar as fontes oficiais, veja os seguintes links:
- https://geoftp.ibge.gov.br/organizacao_do_territorio/malhas_territoriais/malhas_municipais/municipio_2018/Brasil/BR/br_unidades_da_federacao.zip

- https://data.inpe.br/queimadas/bdqueimadas

- https://www.dgi.inpe.br/catalogo/explore
